Setup xdebug tren Visual Code

1. Tao file php chay ham phpinfo(), de lay thong tin PHP, truy cap trang localhost/bai3/info.php
2. Copy toan bo thong tin trong trang roi parse vao xdebug wizard
3. Nhan duoc huong dan cai dat va config xdebug

![IMAGE](https://i.imgur.com/G6uDdYS.png)

4. Vao Visual Code cai dat extension PHP debug
5. Cau hinh launch.json

![IMAGE](https://i.imgur.com/rtBLec4.png)

6. Vao file code php va dat breakpoint, bam F5 de debug, vao browser truy cap trang localhost/bai3/home.php
7. Quay lai Visual Code se nhan duoc thong tin ve variable, callstack, tien hanh step over de debug

![IMAGE](https://i.imgur.com/1TdbitA.png)
 
